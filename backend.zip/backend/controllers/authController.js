import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import User from "../models/User.js";
import Employee from "../models/Employee.js";

function createToken(user) {
  return jwt.sign({ id: user._id, role: user.role, employee: user.employee }, process.env.JWT_SECRET, { expiresIn: "8h" });
}

function userResponse(user) {
  return { id: user._id, name: user.name, email: user.email, role: user.role, employee: user.employee, avatarUrl: user.avatarUrl || "" };
}

export async function register(req, res, next) {
  try {
    const { name, email, password, confirmPassword } = req.body;
    if (!name || !email || !password || !confirmPassword) return res.status(400).json({ message: "name, email, password and confirmPassword are required." });
    if (password.length < 8) return res.status(400).json({ message: "Password must be at least 8 characters long." });
    if (password !== confirmPassword) return res.status(400).json({ message: "Password and confirmation password must match." });
    if (await User.exists({ email: email.toLowerCase() })) return res.status(409).json({ message: "An account already exists for this email." });

    // Public registration cannot grant privileged roles. Administrators assign roles later.
    const employee = await Employee.findOne({ email: email.toLowerCase() });
    const user = await User.create({ name, email, password: await bcrypt.hash(password, 12), role: "employee", employee: employee?._id });
    return res.status(201).json({ user: userResponse(user), token: createToken(user) });
  } catch (error) { next(error); }
}

export async function login(req, res, next) {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email: email?.toLowerCase() }).select("+password");
    if (!user || !(await bcrypt.compare(password || "", user.password))) return res.status(401).json({ message: "Email or password is incorrect." });
    return res.json({ user: userResponse(user), token: createToken(user) });
  } catch (error) { next(error); }
}

export async function updateProfile(req, res, next) {
  try {
    const { name, avatarUrl } = req.body;
    if (!name?.trim()) return res.status(400).json({ message: "A display name is required." });
    const user = await User.findByIdAndUpdate(req.user.id, { name: name.trim(), avatarUrl: avatarUrl?.trim() || "" }, { new: true });
    return res.json({ user: userResponse(user) });
  } catch (error) { next(error); }
}

export async function changePassword(req, res, next) {
  try {
    const { currentPassword, newPassword, confirmPassword } = req.body;
    if (!currentPassword || !newPassword || !confirmPassword) return res.status(400).json({ message: "All password fields are required." });
    if (newPassword.length < 8) return res.status(400).json({ message: "New password must be at least 8 characters long." });
    if (newPassword !== confirmPassword) return res.status(400).json({ message: "New password and confirmation must match." });
    const user = await User.findById(req.user.id).select("+password");
    if (!user || !(await bcrypt.compare(currentPassword, user.password))) return res.status(401).json({ message: "Current password is incorrect." });
    user.password = await bcrypt.hash(newPassword, 12);
    await user.save();
    return res.json({ message: "Password updated successfully." });
  } catch (error) { next(error); }
}
