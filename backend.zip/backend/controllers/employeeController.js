import Employee from "../models/Employee.js";
import { logAudit } from "../utils/audit.js";
import User from "../models/User.js";

export async function getEmployees(req, res, next) {
  try {
    const filter = {};
    if (req.user.role === "employee") {
      if (!req.user.employee) return res.json({ data: [] });
      filter._id = req.user.employee;
    }
    if (req.query.status) filter.status = req.query.status;
    if (req.query.department) filter.department = req.query.department;
    const employees = await Employee.find(filter).sort({ lastName: 1, firstName: 1 });
    res.json({ data: employees });
  } catch (error) { next(error); }
}

export async function createEmployee(req, res, next) {
  try {
    const required = ["employeeCode", "firstName", "lastName", "email", "department", "title", "joinDate", "baseSalary"];
    const missing = required.filter((field) => req.body[field] === undefined || req.body[field] === "");
    if (missing.length) return res.status(400).json({ message: `Missing: ${missing.join(", ")}` });
    const employee = await Employee.create(req.body);
    await User.findOneAndUpdate({ email: employee.email }, { employee: employee._id });
    await logAudit(req.user.id, "Created employee", "Employee", employee._id, { employeeCode: employee.employeeCode });
    res.status(201).json({ data: employee });
  } catch (error) { next(error); }
}

export async function getEmployeeAccounts(req, res, next) {
  try {
    const users = await User.find().select("name email role employee avatarUrl createdAt").populate("employee", "employeeCode firstName lastName department title status").sort({ createdAt: -1 });
    res.json({ data: users });
  } catch (error) { next(error); }
}

export async function updateEmployeeAccountRole(req, res, next) {
  try {
    const allowedRoles = ["admin", "hr_manager", "hr_payroll_manager", "hr_payroll_user", "employee"];
    const { role } = req.body;
    if (!allowedRoles.includes(role)) return res.status(400).json({ message: "Invalid role." });
    if (String(req.user.id) === req.params.id) return res.status(400).json({ message: "You cannot change your own role." });
    const user = await User.findByIdAndUpdate(req.params.id, { role }, { new: true }).select("name email role employee avatarUrl");
    if (!user) return res.status(404).json({ message: "User account not found." });
    await logAudit(req.user.id, "Changed user role", "User", user._id, { role, email: user.email });
    res.json({ data: user });
  } catch (error) { next(error); }
}

export async function updateEmployee(req, res, next) {
  try {
    const employee = await Employee.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!employee) return res.status(404).json({ message: "Employee not found." });
    await logAudit(req.user.id, "Updated employee", "Employee", employee._id, req.body);
    res.json({ data: employee });
  } catch (error) { next(error); }
}
