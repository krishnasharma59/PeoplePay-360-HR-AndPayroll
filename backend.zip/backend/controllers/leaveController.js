import LeaveRequest from "../models/LeaveRequest.js";
import { logAudit } from "../utils/audit.js";

export async function createLeaveRequest(req, res, next) {
  try {
    const employee = req.user.role === "employee" ? req.user.employee : req.body.employee;
    if (!employee) return res.status(400).json({ message: "An employee is required." });
    const leave = await LeaveRequest.create({ ...req.body, employee });
    await logAudit(req.user.id, "Submitted leave request", "LeaveRequest", leave._id);
    res.status(201).json({ data: leave });
  } catch (error) { next(error); }
}

export async function getLeaveRequests(req, res, next) {
  try {
    const filter = req.user.role === "employee" ? { employee: req.user.employee } : {};
    if (req.query.status) filter.status = req.query.status;
    const requests = await LeaveRequest.find(filter).populate("employee", "firstName lastName employeeCode department").sort({ createdAt: -1 });
    res.json({ data: requests });
  } catch (error) { next(error); }
}

export async function decideLeaveRequest(req, res, next) {
  try {
    const { status, approverNotes } = req.body;
    if (!["Approved", "Rejected"].includes(status)) return res.status(400).json({ message: "status must be Approved or Rejected." });
    const leave = await LeaveRequest.findOneAndUpdate({ _id: req.params.id, status: "Pending" }, { status, approverNotes, approvedBy: req.user.id }, { new: true });
    if (!leave) return res.status(404).json({ message: "Pending leave request not found." });
    await logAudit(req.user.id, `${status} leave request`, "LeaveRequest", leave._id);
    res.json({ data: leave });
  } catch (error) { next(error); }
}
