import AttendanceRecord from "../models/AttendanceRecord.js";
import Employee from "../models/Employee.js";
import LeaveRequest from "../models/LeaveRequest.js";
import PayrollRun from "../models/PayrollRun.js";
import Payslip from "../models/Payslip.js";
import { logAudit } from "../utils/audit.js";

export async function createPayrollRun(req, res, next) {
  try {
    const { periodName, startDate, endDate, payDate } = req.body;
    if (!periodName || !startDate || !endDate || !payDate) return res.status(400).json({ message: "periodName, startDate, endDate and payDate are required." });
    const run = await PayrollRun.create({ periodName, startDate, endDate, payDate, createdBy: req.user.id });
    await logAudit(req.user.id, "Created payroll run", "PayrollRun", run._id, { periodName });
    res.status(201).json({ data: run });
  } catch (error) { next(error); }
}

// Calculation is deliberately simple/configurable for the hackathon: 10% tax and unpaid leave at daily salary.
export async function calculatePayroll(req, res, next) {
  try {
    const run = await PayrollRun.findById(req.params.id);
    if (!run) return res.status(404).json({ message: "Payroll run not found." });
    if (run.status !== "Draft") return res.status(409).json({ message: "Only draft payroll runs can be calculated." });

    const [employees, attendance, unpaidLeaves] = await Promise.all([
      Employee.find({ status: "Active" }),
      AttendanceRecord.find({ date: { $gte: run.startDate, $lte: run.endDate } }),
      LeaveRequest.find({ status: "Approved", leaveType: "Unpaid", startDate: { $lte: run.endDate }, endDate: { $gte: run.startDate } }),
    ]);
    const attendanceByEmployee = new Map();
    attendance.forEach((item) => attendanceByEmployee.set(String(item.employee), (attendanceByEmployee.get(String(item.employee)) || 0) + item.overtimeHours));
    const leaveByEmployee = new Map();
    unpaidLeaves.forEach((item) => leaveByEmployee.set(String(item.employee), (leaveByEmployee.get(String(item.employee)) || 0) + item.totalDays));

    const slips = employees.map((employee) => {
      const overtimeHours = attendanceByEmployee.get(String(employee._id)) || 0;
      const unpaidDays = leaveByEmployee.get(String(employee._id)) || 0;
      const overtimePay = overtimeHours * (employee.baseSalary / 160) * 1.5;
      const unpaidLeave = unpaidDays * (employee.baseSalary / 22);
      const gross = employee.baseSalary + employee.fixedAllowances + overtimePay;
      const tax = Math.round((gross - unpaidLeave) * 0.1 * 100) / 100;
      const netPay = Math.max(0, gross - tax - unpaidLeave);
      const flags = [overtimeHours > 20 ? "High overtime: review before approval" : null, unpaidDays > 5 ? "High unpaid leave: review deduction" : null].filter(Boolean);
      return { payrollRun: run._id, employee: employee._id, earnings: { basicSalary: employee.baseSalary, allowances: employee.fixedAllowances, overtimePay, bonus: 0, gross }, deductions: { tax, unpaidLeave, total: tax + unpaidLeave }, netPay, flags };
    });

    await Payslip.deleteMany({ payrollRun: run._id });
    if (slips.length) await Payslip.insertMany(slips);
    run.totals = slips.reduce((totals, slip) => ({ gross: totals.gross + slip.earnings.gross, deductions: totals.deductions + slip.deductions.total, net: totals.net + slip.netPay }), { gross: 0, deductions: 0, net: 0 });
    run.status = "In Review";
    await run.save();
    await logAudit(req.user.id, "Calculated payroll", "PayrollRun", run._id, { employeeCount: slips.length });
    res.json({ data: run, employeeCount: slips.length });
  } catch (error) { next(error); }
}

export async function approvePayroll(req, res, next) {
  try {
    const run = await PayrollRun.findOneAndUpdate({ _id: req.params.id, status: "In Review" }, { status: "Approved", approvedBy: req.user.id }, { new: true });
    if (!run) return res.status(404).json({ message: "Payroll run in review not found." });
    await Payslip.updateMany({ payrollRun: run._id }, { status: "Published" });
    await logAudit(req.user.id, "Approved payroll", "PayrollRun", run._id);
    res.json({ data: run });
  } catch (error) { next(error); }
}

export async function getPayslips(req, res, next) {
  try {
    const run = await PayrollRun.findById(req.params.id);
    if (!run) return res.status(404).json({ message: "Payroll run not found." });
    const filter = { payrollRun: run._id };
    if (req.user.role === "employee") filter.employee = req.user.employee;
    const payslips = await Payslip.find(filter).populate("employee", "firstName lastName employeeCode department");
    res.json({ data: payslips });
  } catch (error) { next(error); }
}
