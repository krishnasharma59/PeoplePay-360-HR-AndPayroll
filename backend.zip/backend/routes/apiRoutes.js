import { Router } from "express";
import { changePassword, login, register, updateProfile } from "../controllers/authController.js";
import { createEmployee, getEmployeeAccounts, getEmployees, updateEmployee, updateEmployeeAccountRole } from "../controllers/employeeController.js";
import { createLeaveRequest, decideLeaveRequest, getLeaveRequests } from "../controllers/leaveController.js";
import { getAttendance, upsertAttendance } from "../controllers/attendanceController.js";
import { approvePayroll, calculatePayroll, createPayrollRun, getPayslips } from "../controllers/payrollController.js";
import AuditLog from "../models/AuditLog.js";
import Employee from "../models/Employee.js";
import LeaveRequest from "../models/LeaveRequest.js";
import PayrollRun from "../models/PayrollRun.js";
import User from "../models/User.js";
import AttendanceRecord from "../models/AttendanceRecord.js";
import { allowRoles, verifyToken } from "../middleware/auth.js";
import { HR_ROLES, PAYROLL_MANAGER_ROLES, PAYROLL_ROLES } from "../middleware/permissions.js";

const router = Router();
const hrRoles = ["admin", "hr_manager", "hr_payroll_manager", "hr_payroll_user"];

router.post("/auth/register", register); // Use only for hackathon setup; restrict/delete in production.
router.post("/auth/login", login);

router.use(verifyToken);
router.patch("/auth/profile", updateProfile);
router.patch("/auth/password", changePassword);
router.get("/employees", getEmployees);
router.post("/employees", allowRoles(...HR_ROLES), createEmployee);
router.patch("/employees/:id", allowRoles(...HR_ROLES), updateEmployee);
router.get("/employee-accounts", allowRoles("admin"), getEmployeeAccounts);
router.patch("/employee-accounts/:id/role", allowRoles("admin"), updateEmployeeAccountRole);

router.get("/leave-requests", getLeaveRequests);
router.post("/leave-requests", createLeaveRequest);
router.patch("/leave-requests/:id/decision", allowRoles(...HR_ROLES), decideLeaveRequest);

router.get("/attendance", getAttendance);
router.put("/attendance", allowRoles("employee", ...HR_ROLES), upsertAttendance);

router.post("/payroll-runs", allowRoles(...PAYROLL_ROLES), createPayrollRun);
router.post("/payroll-runs/:id/calculate", allowRoles(...PAYROLL_ROLES), calculatePayroll);
router.post("/payroll-runs/:id/approve", allowRoles(...PAYROLL_MANAGER_ROLES), approvePayroll);
router.get("/payroll-runs/:id/payslips", allowRoles(...PAYROLL_ROLES), getPayslips);
router.get("/payroll-runs", allowRoles(...PAYROLL_ROLES), async (req, res, next) => {
  try { res.json({ data: await PayrollRun.find().sort({ createdAt: -1 }) }); } catch (error) { next(error); }
});

router.get("/dashboard/summary", async (req, res, next) => {
  try {
    if (!hrRoles.includes(req.user.role)) {
      return res.json({ data: { totalEmployees: 0, pendingLeave: 0, currentPayroll: null, recentActivity: [], attendance: { totalEligible: 0, presentTotal: 0, inOffice: 0, remote: 0, onLeave: 0 } } });
    }
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    const [totalEmployees, pendingLeave, currentPayroll, recentActivity, attendance] = await Promise.all([
      User.countDocuments(),
      LeaveRequest.countDocuments({ status: "Pending" }),
      PayrollRun.findOne().sort({ createdAt: -1 }),
      AuditLog.find().populate("actor", "name role").sort({ createdAt: -1 }).limit(8),
      AttendanceRecord.aggregate([
        { $match: { date: { $gte: today, $lt: tomorrow } } },
        { $group: { _id: "$status", count: { $sum: 1 } } },
      ]),
    ]);
    const attendanceCounts = Object.fromEntries(attendance.map((item) => [item._id, item.count]));
    res.json({ data: {
      totalEmployees,
      pendingLeave,
      currentPayroll,
      recentActivity,
      attendance: {
        totalEligible: totalEmployees,
        presentTotal: (attendanceCounts.Present || 0) + (attendanceCounts.Remote || 0),
        inOffice: attendanceCounts.Present || 0,
        remote: attendanceCounts.Remote || 0,
        onLeave: attendanceCounts["On Leave"] || 0,
      },
    } });
  } catch (error) { next(error); }
});
router.get("/audit-logs", allowRoles("admin", "hr_manager", "hr_payroll_manager"), async (req, res, next) => {
  try { res.json({ data: await AuditLog.find().populate("actor", "name role").sort({ createdAt: -1 }).limit(100) }); } catch (error) { next(error); }
});

export default router;
